
<?php $__env->startSection('content'); ?>
                    <div class="col-lg-9">
                        <div class="blog-list clearfix">
                            <div class="section-title">
                                <h3 class="color-green"><a href="blog-category-01.html" title="">Job Listings</a></h3>
                            </div><!-- end title -->
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($post->status === "Post"): ?>
                            <div class="blog-box row">
                                <div class="col-md-4">
                                    <div class="post-media">
                                        <a href="single.html" title="">
                                            <img src="https://cdn.erakomp.co.id/assets/joblisting/images/20943993.jpg" alt="" class="img-fluid">
                                            <div class="hovereffect"></div>
                                        </a>
                                    </div><!-- end media -->
                                </div><!-- end col -->
                               
                                <div class="blog-meta big-meta col-md-8">
                                    <h4><a href="/details/<?php echo e($post->id); ?>" title=""><?php echo e($post->title); ?></a></h4>
                                    <p><?php echo e($post->description); ?></p>
                                    <small><a href="blog-category-01.html" title=""><?php echo e($post->created_at->format('l, Y-m-d')); ?></a></small>
                                    
                                </div><!-- end meta -->
                            </div><!-- end blog-box -->

                            <hr class="invis">
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div><!-- end blog-list -->
                    </div><!-- end col -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.listing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/board.blade.php ENDPATH**/ ?>