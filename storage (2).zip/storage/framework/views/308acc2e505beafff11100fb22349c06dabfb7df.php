

<?php $__env->startSection('content'); ?>

<h2>Referensi</h2>
<div class="mt-2">
    <a href=" <?php echo e(route('reference.create')); ?> " class="btn btn-primary mb-3">+ Referensi</a>
</div>
<?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card mb-2">
    <div class="card-body">
        <h4 class="card-title"> <?php echo e($e->name); ?>  </h4>

        <ul>
            <li>Alamat: <?php echo e($e->address); ?></li>
            <li>Nomor Telepon: <?php echo e($e->phone); ?></li>
            <li>Jabatan: <?php echo e($e->position); ?></li>
        </ul>

    <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('reference.edit', $e)); ?> " role="button">Edit</a>

        <form action="<?php echo e(route('reference.destroy', $e)); ?>" method="POST" style="display: inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="submit" value="Delete" class="btn btn-sm btn-danger">
        </form>

    </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="text-right">
    <a class=" btn btn-primary mt-3" href=" <?php echo e(route('married.create')); ?> " role="button">Next</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/reference/index.blade.php ENDPATH**/ ?>