
  
<?php $__env->startSection('content'); ?>
   
<div class="container mt-5">
   
    <div class="row justify-content-center align-items-center">
        
        <div class="card" style="width: 24rem;">
            <div class="card-header" style="font-size: 21px;"><b>
            Edit Status</b>
            
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>" id="myForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name">Name: </label>                    
                    <label for=""><?php echo e($user->name); ?></label>  
                </div>
                <br>
                <div class="form-group">
                    <label for="email">Email: </label>                    
                    <label for=""><?php echo e($user->email); ?></label>
                </div>
                <br>
                <div class="form-group">
                    <label for="writer">Status</label>                    
                    <select name="status" id="" >
                        <option value="<?php echo e($user->status); ?>"><?php echo e($user->status); ?></option>
                        <option value="On Hold">On Hold</option>
                        <option value="In Progress">In Progress</option>

                    </select>
                </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            <a class=" btn btn-primary" href=" /admin/home" role="button">Back</a>

            </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/users/edit.blade.php ENDPATH**/ ?>