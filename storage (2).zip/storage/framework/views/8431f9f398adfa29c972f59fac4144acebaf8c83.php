

<?php $__env->startSection('content'); ?>
<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
    <div class="card-body">
<div class="container">
    <h2>Gambar Profile</h2>


    <form action="/image" method='POST' enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <input type="file" name='image' placeholder='Image'>

     
<br>
        
        <input type="submit" class="btn btn-primary mt-3" value="Submit" style="margin-left: 50%; margin-right:50%;">

    </form>

</div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/image/create.blade.php ENDPATH**/ ?>