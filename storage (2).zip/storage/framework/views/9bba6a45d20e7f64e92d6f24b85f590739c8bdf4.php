

<?php $__env->startSection('content'); ?>

<h2>Pengalaman Kerja</h2>
<div class="mt-2">
    <a href=" <?php echo e(route('experience.create')); ?> " class="btn btn-primary mb-3">+ Pengalaman Kerja</a>
</div>
<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
    <div class="card-body">
        <h4 class="card-title"> <?php echo e($e->position); ?>  (<?php echo e($e->from); ?> sampai <?php echo e($e->to); ?>) </h4>

        <ul>
            <li>Nama Perusahaan: <?php echo e($e->company_name); ?></li>
            <li>Gaji Pokok: <?php echo e($e->salary); ?></li>
            <li>Alasan Keluar: <?php echo e($e->reason); ?></li>
            <li>Deskripsi Pekerjaan: <?php echo e($e->description); ?></li>
        </ul>

    <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('experience.edit', $e)); ?> " role="button">Edit</a>

        <form action="<?php echo e(route('experience.destroy', $e)); ?>" method="POST" style="display: inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="submit" value="Delete" class="btn btn-sm btn-danger">
        </form>

    </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="text-right">
    <a class=" btn btn-primary mt-3" href=" <?php echo e(route('skill.index')); ?> " role="button">Next</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/experience/index.blade.php ENDPATH**/ ?>