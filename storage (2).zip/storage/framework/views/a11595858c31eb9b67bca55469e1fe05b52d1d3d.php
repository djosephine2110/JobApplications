

<?php $__env->startSection('content'); ?>

<h2>Anak (jika ada)</h2>
<div class="mt-2">
    <a href=" <?php echo e(route('anak.create')); ?> " class="btn btn-primary mb-3">+ Anak</a>
</div>
<?php $__currentLoopData = $anaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
    <div class="card-body">
        <h4 class="card-title"> <?php echo e($e->name); ?>  </h4>

        <ul>
            <li><?php echo e($e->gender); ?></li>
            <li><?php echo e($e->dob); ?></li>
            <li><?php echo e($e->education); ?></li>
        </ul>

    <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('anak.edit', $e)); ?> " role="button">Edit</a>

        <form action="<?php echo e(route('anak.destroy', $e)); ?>" method="POST" style="display: inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="submit" value="Delete" class="btn btn-sm btn-danger">
        </form>

    </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="text-right">
    <a class=" btn btn-primary mt-3" href=" <?php echo e(route('skill.index')); ?> " role="button">Next</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/anak/index.blade.php ENDPATH**/ ?>