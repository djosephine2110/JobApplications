

<?php $__env->startSection('content'); ?>

<h2>Status</h2>
<div class="mt-2">
</div>
<?php $__empty_1 = true; $__currentLoopData = $marrieds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
    <div class="card-body">
        <h4 class="card-title"> <?php echo e($e->married_status); ?>  </h4>

        <ul>
            <li>Nama Pasangan: <?php echo e($e->spouse_name); ?></li>
            <li>Tempat Lahir: <?php echo e($e->spouse_bplace); ?></li>
            <li>Tanggal Lahir: <?php echo e($e->spouse_dob); ?></li>
            <li>Pendidikan: <?php echo e($e->spouse_education); ?></li>
            <li>Pekerjaan: <?php echo e($e->spouse_job); ?></li>
        </ul>

    <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('married.edit', $e)); ?> " role="button">Edit</a>

        <form action="<?php echo e(route('married.destroy', $e)); ?>" method="POST" style="display: inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="submit" value="Delete" class="btn btn-sm btn-danger">
        </form>

    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="mt-2">
  <a href=" <?php echo e(route('married.create')); ?> " class="btn btn-primary mb-3">+ Status</a>
</div>

<?php endif; ?>


<div class="text-right">
    <a class=" btn btn-primary mt-3" href=" <?php echo e(route('children.index')); ?> " role="button">Next</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/married/index.blade.php ENDPATH**/ ?>