

<?php $__env->startSection('content'); ?>
<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
  <div class="card-body">
<div class="container">
    <h2>Pekerjaan yang Dilamar</h2>


    <form action="/job" method='POST'>
        <?php echo csrf_field(); ?>

        <div class="form-row">
            <div class="form-group col-md-6">
              <label for="company_name">Nama Posisi yang diinginkan</label>
              <input type="text" class="form-control" name="job_name" id="name" value="<?php echo e(Auth::user()->category); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="position">Posisi</label>
              <input type="text" class="form-control" name="job_position" id="position" >
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="company_name">Gaji yang diharapkan</label>
              <input type="text" class="form-control" name="job_salary" id="name" >
            </div>
            <div class="form-group col-md-6">
              <label for="position">Fasilitas yang diharapkan</label>
              <input type="text" class="form-control" name="job_facilities" id="position" >
            </div>
          </div>
    
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="from">Mulai</label>
              <input type="date" class="form-control" name="job_starts" id="name">
            </div>
           
          </div>
    
          
        
        <input type="submit" value="Submit" class="btn btn-primary" style="margin-left:46%; margin-right:50%;">

    </form>

</div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/job/create.blade.php ENDPATH**/ ?>