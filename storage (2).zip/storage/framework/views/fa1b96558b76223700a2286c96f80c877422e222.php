

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
<h2>Job Posting</h2>

<?php $__currentLoopData = $posting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.507);">
    <div class="card-body">
        <h4 class="card-title"> <?php echo e($e->title); ?>  </h4>

        <ul>
            <li>Created at: <?php echo e($e->created_at->format('l, d-m-Y')); ?></li>
            <li>Status: <?php echo e($e->status); ?></li>
        </ul>

    <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('posting.edit', $e)); ?> " role="button">Edit Status</a>

       <!-- <form action="<?php echo e(route('posting.destroy', $e)); ?>" method="POST" style="display: inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="submit" value="Delete" class="btn btn-sm btn-danger">
        </form>-->

    </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/posting/index.blade.php ENDPATH**/ ?>