

<?php $__env->startSection('content'); ?>
<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
  <div class="card-body">
<div class="container">
    <h2>Edit Referensi</h2>

    <form action="<?php echo e(route('kerjaan.update', $kerjaan)); ?>" method='POST'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="name">Nama Posisi yang diinginkan</label>
            <input type="text" class="form-control" name="job_name" id="job_name" value=<?php echo e($kerjaan->job_name); ?>>
          </div>
          <div class="form-group col-md-6">
            <label for="phone">Posisi</label>
            <input type="text" class="form-control" name="job_position" id="position" value=<?php echo e($kerjaan->job_position); ?>>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="address">Gaji yang diharapkan</label>
            <input type="text" class="form-control" name="job_salary" id="name" value=<?php echo e($kerjaan->job_salary); ?>>
          </div>
          <div class="form-group col-md-6">
            <label for="position">Fasilitas yang diharapkan</label>
            <input type="text" class="form-control" name="job_facilities" id="position" value=<?php echo e($kerjaan->job_facilities); ?>>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="address">Mulai</label>
            <input type="date" class="form-control" name="job_starts" id="name" value=<?php echo e($kerjaan->job_starts); ?>>
          </div>
         
        </div>
      
        <input type="submit" value="Save" class="btn btn-primary" style="margin-left:46%; margin-right:50%;">

    </form>

</div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/kerjaan/edit.blade.php ENDPATH**/ ?>