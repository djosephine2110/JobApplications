
<button type="submit" class="btn btn-primary mt-2">Submit</button>
<?php /**PATH D:\jobClone\JobApplications\resources\views/components/form/submit.blade.php ENDPATH**/ ?>