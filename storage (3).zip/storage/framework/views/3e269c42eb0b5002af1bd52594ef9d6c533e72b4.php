

<?php $__env->startSection('content'); ?>
<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
  <div class="card-body">
<div class="container">
    <h2>Keahlian Lain</h2>


    <form action="/skill" method='POST'>
        <?php echo csrf_field(); ?>

        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Nama Keahlian</label>
            <input type="text" class="form-control" name="name" id="inputEmail4">
          </div>
          <div class="form-group col-md-6">
            <label for="inputPassword4">Penilaian</label>
            <select id="inputState" name="rating" class="form-control">
              <option selected>Choose...</option>
              <option value="Sangat Baik">Sangat Baik</option>

              <option value="Baik">Baik</option>
              <option value="Cukup">Cukup</option>

              <option value="Kurang">Kurang</option>
              <option value="Sangat Kurang">Sangat Kurang</option>

            </select>
            </div>
        </div>

        


        <input type="submit" value="Submit" class="btn btn-primary" style="margin-left:40%; margin-right:50%;">

    </form>

</div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/skills/create.blade.php ENDPATH**/ ?>