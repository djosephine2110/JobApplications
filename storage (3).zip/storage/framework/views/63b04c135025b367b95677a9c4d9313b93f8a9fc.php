

<?php $__env->startSection('content'); ?>
<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.507);">
  <div class="card-body">
<div class="container">
    <h2>Job Posts</h2>


    <form action="/post" method='POST'>
        <?php echo csrf_field(); ?>

        <div class="form-row">
            <div class="form-group col-md-6">
              <label for="title">Job Title</label>
              <input type="text" class="form-control" name="title" id="name" placeholder="" value="<?php echo e($post->title); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="description">Job Description</label>
              <textarea type="text" class="form-control" name="description" id="position" value="<?php echo e($post->description); ?>"><?php echo e($post->description); ?></textarea>
            </div>
          </div>
    
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="education">Education</label>
              <input type="text" class="form-control" name="education" id="name" value="<?php echo e($post->education); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="post">Experiences</label>
              <input type="text" class="form-control" name="experience" id="position" value="<?php echo e($post->experience); ?>">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="inputEmail4">Status</label>
              <select id="inputState" name="status" class="form-control">
                <option value="<?php echo e($post->status); ?>" selected>
                  <?php if($post->status == 1): ?>
                  Post
                  <?php else: ?>
                  On Hold
                  <?php endif; ?>
                </option>
                <option value="0">On Hold</option>
                <option value="1">Post</option>
  
              </select>          
            </div>
            
          </div>


        <input type="submit" value="Submit" class="btn btn-primary" style="margin-left:46%; margin-right:50%;">

    </form>

</div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/post/edit.blade.php ENDPATH**/ ?>