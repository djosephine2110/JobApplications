<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>ERAKOMP CAREER</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    
    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .active {
            font-weight: bolder;
        }
    </style>
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    ERAKOMP CAREER
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                        <li class='nav-item'>
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modelId">
                                Preview
                            </button>

                            <!-- Modal -->
                            <div class="modal fade " id="modelId" tabindex="-1" role="dialog"
                                aria-labelledby="modelTitleId" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Preview Application</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="container-fluid">
                                                <iframe width='100%' height='900'  src="<?php echo e(route('resume.index')); ?>"></iframe>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">Close</button>
                                            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('resume.download')); ?>"
                                                role="button">Download</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <!--<div class="nav-item">
                            <a target="_blank" href=" <?php echo e(route('resume.index')); ?> " class="btn btn-primary ml-3"> View</a>
                        </div>
                    -->



                    </ul>
                   
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php else: ?>
                        <span class="badge badge-success" style="height: 20px;"><?php echo e(Auth::user()->status); ?></span>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
               <i class="fas fa-power-off"></i>
           </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                        
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>


        <main class="py-4 container">

            <?php if(auth()->guard()->check()): ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item <?php echo e(request()->is('user-detail') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('user-detail.index')); ?>">Bio</a></li>
                    <li class="breadcrumb-item <?php echo e(request()->is('education') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('education.index')); ?>">Pendidikan</a></li>
                    <li class="breadcrumb-item <?php echo e(request()->is('experience') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('experience.index')); ?>">Pengalaman Kerja</a></li>
                    <li class="breadcrumb-item <?php echo e(request()->is('skill') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('skill.index')); ?>">Keahlian</a></li>
                            <li class="breadcrumb-item <?php echo e(request()->is('asing') ? 'active' : ''); ?>"><a
                                href="<?php echo e(route('asing.index')); ?>">Bahasa Asing</a></li>
                                <li class="breadcrumb-item <?php echo e(request()->is('reference') ? 'active' : ''); ?>"><a
                                    href="<?php echo e(route('reference.index')); ?>">Referensi</a></li>
                                    <li class="breadcrumb-item <?php echo e(request()->is('married') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('married.index')); ?>">Status</a></li>
                                        <li class="breadcrumb-item <?php echo e(request()->is('anak') ? 'active' : ''); ?>"><a
                                            href="<?php echo e(route('anak.index')); ?>">Anak</a></li>
                                            <li class="breadcrumb-item <?php echo e(request()->is('relation') ? 'active' : ''); ?>"><a
                                                href="<?php echo e(route('relation.index')); ?>">Relasi</a></li>
                                                <li class="breadcrumb-item <?php echo e(request()->is('organization') ? 'active' : ''); ?>"><a
                                                    href="<?php echo e(route('organization.index')); ?>">Organisasi</a></li>
                                                    <li class="breadcrumb-item <?php echo e(request()->is('health') ? 'active' : ''); ?>"><a
                                                        href="<?php echo e(route('health.create')); ?>">Kesehatan</a></li>
                                                        <li class="breadcrumb-item <?php echo e(request()->is('job') ? 'active' : ''); ?>"><a
                                                            href="<?php echo e(route('kerjaan.index')); ?>">Pekerjaan yang dilamar</a></li>
                                                            <li class="breadcrumb-item <?php echo e(request()->is('connection') ? 'active' : ''); ?>"><a
                                                                href="<?php echo e(route('connection.index')); ?>">Rekomendasi Dari Perusahaan</a></li>
                            
                                

                </ol>
            </nav>
            <?php endif; ?>

            
            <div>
               
            </div>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>

</html>
<?php /**PATH D:\jobClone\JobApplications\resources\views/layouts/app.blade.php ENDPATH**/ ?>