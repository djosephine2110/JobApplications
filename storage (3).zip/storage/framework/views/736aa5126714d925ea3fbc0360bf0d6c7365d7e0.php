

<?php $__env->startSection('content'); ?>

<h2>Keahlian</h2>
<div class="mt-2">
    <a href=" <?php echo e(route('skill.create')); ?> " class="btn btn-primary">+ Keahlian</a>
</div>
<br>

<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="background-color:rgba(255, 255, 255, 0.788);">
    <div class="card-body">
        <h4 class="card-title"> <?php echo e($e->name); ?> ( <?php echo e($e->rating); ?> )</h4>


    <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('skill.edit', $e)); ?> " role="button">Edit</a>

        <form action="<?php echo e(route('skill.destroy', $e)); ?>" method="POST" style="display: inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <input type="submit" value="Delete" class="btn btn-sm btn-danger">
        </form>

    </div>
</div>
<br>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<div class="text-right">
    <a class=" btn btn-primary" href=" <?php echo e(route('asing.index')); ?> " role="button">Next</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/skills/index.blade.php ENDPATH**/ ?>