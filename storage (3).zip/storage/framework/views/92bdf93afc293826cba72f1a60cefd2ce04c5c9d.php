

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Koneksi</h2>


    <form action="/connection" method='POST'>
        <?php echo csrf_field(); ?>

        <div class="form-row">
            <div class="form-group col-md-6">
              <label for="name">Nama</label>
              <input type="text" class="form-control" name="name" id="name" placeholder="example: John Doe">
            </div>
            <div class="form-group col-md-6">
              <label for="position">Jabatan</label>
              <input type="text" class="form-control" name="position" id="position" placeholder="example: Manager">
            </div>
          </div>
    
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="from">Hubungan</label>
              <input type="text" class="form-control" name="relationship" id="name" placeholder="example: Friend">
            </div>
            
          </div>
    
         
        <input type="submit" value="Submit" class="btn btn-primary" style="margin-left:46%; margin-right:50%;">

    </form>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/connection/create.blade.php ENDPATH**/ ?>