

<?php $__env->startSection('content'); ?>

<h2>Biografi</h2>
<div class="mt-2">
</div>

<?php $__empty_1 = true; $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<div class="card mb-2" style="background-color:rgba(255, 255, 255, 0.788);">
  <div class="card-body">
      <h4 class="card-title">Bio Review Page</h4>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="name">Name:</label> <?php echo e($e->name); ?>

        </div>
        <div class="form-group col-md-6">
          <label for="ktp">KTP:</label> <?php echo e($e->ktp); ?>

        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="birth_place">Tempat Lahir: </label><?php echo e($e->birth_place); ?>

        </div>
        <div class="form-group col-md-6">
          <label for="dob">Tanggal Lahir: </label> <?php echo e($e->dob); ?>

        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="gender">Jenis Kelamin :</label> <?php echo e($e->gender); ?>

          <br>
          
          
        </div>
        <div class="form-group col-md-6">
          <label for="religion">Agama: </label> <?php echo e($e->religion); ?>

                       
        </div>
      </div>
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="address">Alamat: </label> <?php echo e($e->address); ?>

        </div>
        <div class="form-group col-md-6">
          <label for="zipcode">Kode Pos: </label> <?php echo e($e->zipcode); ?>

        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="phone">Nomor Telepon: </label> <?php echo e($e->phone); ?>

        </div>
        <div class="form-group col-md-6">
          <label for="home_number">Telepon Rumah: </label> <?php echo e($e->home_number); ?>

        </div>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="sim_a">SIM A: </label> <?php echo e($e->sim_a); ?>

        </div>
        <div class="form-group col-md-6">
          <label for="sim_c">SIM C: </label> <?php echo e($e->sim_c); ?>

        </div>
      </div>
    
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="vehicle">Kendaraan: </label> <?php echo e($e->vehicle); ?>

         
        </div>
        <div class="form-group col-md-6">
          <label for="hobby">Hobi: </label> <?php echo e($e->hobby); ?>

        </div>
      </div>
    

    

  <a  class="btn btn-sm btn-primary" href=" <?php echo e(route('user-detail.edit', $e)); ?> " role="button">Edit</a>

      <form action="<?php echo e(route('user-detail.destroy', $e)); ?>" method="POST" style="display: inline">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>

      <input type="submit" value="Delete" class="btn btn-sm btn-danger">
      </form>

  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="mt-2">
  <a href=" <?php echo e(route('user-detail.create')); ?> " class="btn btn-primary mb-3">+ Biography</a>
</div>


<?php endif; ?>


<div class="text-right">
    <a class=" btn btn-primary mt-3" href=" <?php echo e(route('skill.index')); ?> " role="button">Next</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/user_detail/index.blade.php ENDPATH**/ ?>