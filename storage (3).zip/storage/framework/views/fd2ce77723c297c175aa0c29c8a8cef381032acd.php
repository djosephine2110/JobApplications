<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Resume</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        body {
            font-size: 12px;

        }

        h2 {
            font-weight: 100;
            padding: 20px 0;
            border-top: 1px solid black;
            border-bottom: 1px solid black;
        }

        .container {
            width: 70%;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="container">
        <br>
        <br>
        
        <section class="heading">
            <?php $__currentLoopData = $user->details->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2 class="text-center"><b>Application of <?php echo e($e->name); ?></b></h2>

            <p><b>Nama Lengkap:</b> <?php echo e($e->name); ?> </p>
            <p><b>KTP:</b> <?php echo e($e->ktp); ?></p>
            <p><b>Tempat Lahir: </b> <?php echo e($e->birth_place); ?></p>
            <p><b>Tanggal Lahir:</b> <?php echo e($e->dob); ?> </p>
            <p><b>Jenis Kelamin:</b> <?php echo e($e->gender); ?> </p>
            <p><b>Agama:</b> <?php echo e($e->religion); ?></p>
            <p><b>Alamat:</b> <?php echo e($e->address); ?></p>
            <p><b>Kode Pos:</b> <?php echo e($e->zipcode); ?></p>
            <p><b>Telepon 1:</b> <?php echo e($e->phone); ?></p>
            <p><b>Telepon 2:</b> <?php echo e($e->home_number); ?></p>
            <p><b>SIM A:</b> <?php echo e($e->sim_a); ?></p>
            <p><b>SIM C:</b> <?php echo e($e->sim_c); ?></p>
            <p><b>Kendaraan:</b> <?php echo e($e->vehicle); ?></p>
            <p><b>Kegemaran:</b> <?php echo e($e->hobby); ?></p>

            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </section>


        <section class="education">

            <h2><b>Pendidikan</b></h2>

            <?php $__currentLoopData = $user->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <p style="font-size: 15px;"><b><?php echo e($e->degree); ?> (<?php echo e($e->graduation_start_date); ?> - <?php echo e($e->graduation_end_date); ?>)</b></p>

            <p><b>Nama Institusi: </b><?php echo e($e->school_name); ?> </p>
            <p><b>Alamat: </b><?php echo e($e->school_location); ?></p>
            <p><b>Jurusan:  </b><?php echo e($e->field_of_study); ?></p>
            
            <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <section class="foreign">

          <h2><b>Bahasa Asing</b></h2>

          <?php $__currentLoopData = $user->asings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <p style="font-size: 15px;"><b><?php echo e($e->language); ?></b></p>

          <p><b>Bicara: </b><?php echo e($e->speaking); ?> </p>
          <p><b>Membaca: </b><?php echo e($e->reading); ?></p>
          <p><b>Menulis:  </b><?php echo e($e->writing); ?></p>
          
          <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </section>

      <section class="skills">

        <h2><b>Keahlian Lainnya</b></h2>

        <?php $__currentLoopData = $user->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p style="font-size: 15px;"> <b><?php echo e($skill->name); ?></b></p>
        <p><b>Penilaian: </b><?php echo e($skill->rating); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

        <section class="work">

            <h2><b>Pengalaman Kerja</b></h2>

            <?php $__currentLoopData = $user->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p style="font-size: 15px;"><b>
                <?php echo e($work->company_name); ?> (<?php echo e($work->from); ?> - <?php echo e($work->to); ?>)
            </b></p>
            <p><b>Jabatan: </b><?php echo e($work->position); ?> </p>
            <p><b>Gaji: </b><?php echo e($work->salary); ?> </p>
            <p><b>Alasan Keluar: </b><?php echo e($work->reason); ?> </p>
            <p><b>Deskripsi Pekerjaan: </b><?php echo e($work->description); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <section class="Nikah">

          <h2><b>Status Pernikahan</b></h2>

          <?php $__currentLoopData = $user->marrieds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <p><b>Status: </b><?php echo e($m->married_status); ?> </p>
          <p><b>Nama Pasangan: </b><?php echo e($m->spouse_name ?? 'tidak ada'); ?>  </p>
          <p><b>Tempat Lahir: </b><?php echo e($m->spouse_bplace ?? 'tidak ada'); ?> </p>
          <p><b>Tanggal Lahir: </b><?php echo e($m->spouse_dob ?? 'tidak ada'); ?></p>
          <p><b>Pendidikan: </b><?php echo e($m->spouse_education ?? 'tidak ada'); ?></p>
          <p><b>Pekerjaan: </b><?php echo e($m->spouse_job ?? 'tidak ada'); ?></p>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </section>

      <section class="Anak">

        <h2><b>Anak</b></h2>

        <?php $__currentLoopData = $user->anaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <p><b>Nama Anak: </b><?php echo e($m->name); ?> </p>
        <p><b>Jenis Kelamin: </b><?php echo e($m->gender ?? 'tidak ada'); ?>  </p>
        <p><b>Tanggal Lahir: </b><?php echo e($m->dob ?? 'tidak ada'); ?> </p>
        <p><b>Pendidikan: </b><?php echo e($m->education ?? 'tidak ada'); ?></p>
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
        

    <section class="Relasi">

        <h2><b>Relasi</b></h2>

        <?php $__currentLoopData = $user->relations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <p><b>Nama:</b> <?php echo e($m->name); ?> </p>
        <p><b>Hubungan:</b> <?php echo e($m->relationship ?? 'tidak ada'); ?>  </p>
        <p><b>Tanggal Lahir:</b> <?php echo e($m->dob ?? 'tidak ada'); ?> </p>
        <p><b>Pekerjaan:</b> <?php echo e($m->job ?? 'tidak ada'); ?></p>
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
        

    <section class="Organisasi">

        <h2><b>Organisasi</b></h2>

        <?php $__currentLoopData = $user->organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <p style="font-size: 15px;"><b><?php echo e($m->name); ?> (<?php echo e($m->from); ?> - <?php echo e($m->to); ?>)</b></p>
        <p><b>Alamat: </b><?php echo e($m->address ?? 'tidak ada'); ?>  </p>
        <p><b>Jabatan: </b><?php echo e($m->position ?? 'tidak ada'); ?> </p>
        <br>
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <section class="Data Kesehatan">

        

        <?php $__currentLoopData = $user->healths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <p><b>Golongan Darah: </b><?php echo e($m->blood_type ?? 'tidak ada'); ?>  </p>
        <p><b>Penyakit Ringan: </b><?php echo e($m->light_disease ?? 'tidak ada'); ?> </p>
        <p><b>Penyakit Berat: </b><?php echo e($m->heavy_disease ?? 'tidak ada'); ?> </p>
        <p><b>Pernah Dirawat: </b><?php echo e($m->opname ?? 'tidak ada'); ?> </p>
        <p><b>Alasan Dirawat: </b><?php echo e($m->alasan ?? 'tidak ada'); ?> </p>
        <p><b>Pengelihatan: </b><?php echo e($m->eyesight ?? 'tidak ada'); ?> </p>
        <p><b>Pendengaran: </b><?php echo e($m->hearing ?? 'tidak ada'); ?> </p>
        <p><b>Kesehatan: </b><?php echo e($m->health ?? 'tidak ada'); ?> </p>
        <hr>
        <p>Kontak Darurat</p>
        <p><b>Nama: </b><?php echo e($m->name ?? 'tidak ada'); ?> </p>
        <p><b>Alamat: </b><?php echo e($m->address ?? 'tidak ada'); ?> </p>
        <p><b>Kode Pos: </b><?php echo e($m->zipcode ?? 'tidak ada'); ?> </p>
        <p><b>Nomor Telepon: </b><?php echo e($m->phone ?? 'tidak ada'); ?> </p>
        <p><b>Hubungan: </b><?php echo e($m->relation ?? 'tidak ada'); ?> </p>

        <br>
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <section class="Referensi">

        <h2><b>Referensi</b></h2>

        <?php $__currentLoopData = $user->references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <p style="font-size: 15px;"><b><?php echo e($m->name); ?></b></p>
        <p><b>Alamat: </b><?php echo e($m->address ?? 'tidak ada'); ?>  </p>
        <p><b>Nomor Telepon: </b><?php echo e($m->phone ?? 'tidak ada'); ?></p>
        <p><b>Jabatan: </b><?php echo e($m->position ?? 'tidak ada'); ?> </p>
        <br>
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <section class="Connection">

        <h2><b>Rekomendasi Dari Perusahaan</b></h2>

        <?php $__currentLoopData = $user->connections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <p style="font-size: 15px;"><b><?php echo e($m->name); ?></b></p>
        <p><b>Jabatan: </b><?php echo e($m->position ?? 'tidak ada'); ?> </p>
        <p><b>Hubungan: </b><?php echo e($m->relationship ?? 'tidak ada'); ?></p>
        <br>
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <section class="Connection">

        <h2><b>Informasi Pekerjaan Yang Dilamar</b></h2>

        <?php $__currentLoopData = $user->kerjaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <p style="font-size: 15px;"><b><?php echo e($m->job_name); ?></b></p>
        <p><b>Jabatan yang diinginkan: </b><?php echo e($m->job_position ?? 'tidak ada'); ?> </p>
        <p><b>Gaji yang diharapkan: </b><?php echo e($m->job_salary ?? 'tidak ada'); ?></p>
        <p><b>Fasilitas yang diharapkan: </b><?php echo e($m->job_facilities ?? 'tidak ada'); ?></p>
        <p><b>Kapan dapat mulai bekerja: </b><?php echo e($m->job_starts ?? 'tidak ada'); ?></p>

        <br>
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    </div>
</body>

</html>
<?php /**PATH D:\jobClone\JobApplications\resources\views/print.blade.php ENDPATH**/ ?>