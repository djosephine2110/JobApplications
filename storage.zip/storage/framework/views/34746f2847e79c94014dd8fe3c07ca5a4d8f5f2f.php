
   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-color:rgba(255, 255, 255, 0.788);">
                <div class="card-header">ERA CAREER</div>
                <div class="card-body">
                    <h2>Hi <?php echo e(Auth::user()->name); ?>,</h2>
                    <p>Tolong upload gambar profile anda untuk melanjutkan ke proses selanjutnya, atau jika sudah memiliki gambar profile anda bisa melanjutkan ke halaman selanjutnya. Jika tidak meng-upload CV anda, maka aplikasi anda dianggap belum lengkap.</p>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('home')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for=""><b>Unduh Gambar Profile</b></label><br>
                        <input type="file" name="image" class="mb-3" onchange="loadPreview(this);" id="profile_image">
                        <img id="preview_img" src="<?php echo e(asset('/storage/images/'.Auth::user()->image)); ?>" class="img-thumbnail" style="max-width: 250px;" />

                        <br>
                        <label for=""><b>Unduh CV</b></label><br>
                        <input type="file" name="file" class="mb-3" >
                        <label for=""><?php echo e(Auth::user()->file ?? 'No File Upload'); ?></label>
                        <br>

                        
                            <label for="inputEmail4">Select Job Category</label>
                            <select id="inputState" name="category" class="form-control">
                                <option value="<?php echo e(Auth::user()->category); ?>" selected><?php echo e(Auth::user()->category); ?></option>
                                <option value="IT">IT</option>
                                <option value="HRD">HRD</option>
                                <option value="Finance">Finance</option>
                                <option value="Product">Product</option>
                                <option value="Sales">Sales</option>
                                <option value="Legal">Legal</option>
                                <option value="Social Media">Social Media</option>

                                <option value="Others">Others</option>
                  
                              </select>          
                        <input type="submit" value="Submit" class="btn btn-primary mt-3" >
                        <a class=" btn btn-primary mt-3" href="/user-detail " role="button" style="float:right;">Next</a>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function loadPreview(input, id) {
      id = id || '#preview_img';
      if (input.files && input.files[0]) {
          var reader = new FileReader();
   
          reader.onload = function (e) {
              $(id)
                      .attr('src', e.target.result, '.img-thumbnail')
                      .width(200)
                      .height(150);
          };
   
          reader.readAsDataURL(input.files[0]);
      }
   }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/home.blade.php ENDPATH**/ ?>