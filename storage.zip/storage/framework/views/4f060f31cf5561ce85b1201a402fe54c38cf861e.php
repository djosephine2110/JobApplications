

<?php $__env->startSection('content'); ?>

<div class="container">

    <h2>Welcome to Erakomp Career</h2>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">Nama</th>
            <th scope="col">Email</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>  
          
            <th scope="row"><?php echo e($detail->name); ?></th>
            <th><?php echo e($detail->email); ?></th>
            <td><a href="/test_detail/<?php echo e($detail->id); ?>">View</a></td>
            <td><a href="/download/<?php echo e($detail->id); ?>">Download</a></td>

          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/test.blade.php ENDPATH**/ ?>