

<?php $__env->startSection('content'); ?>
<div class="card mb-2">
  <div class="card-body">
<div class="container">
    <h2>Referensi</h2>


    <form action="/reference" method='POST'>
        <?php echo csrf_field(); ?>

        <div class="form-row">
            <div class="form-group col-md-6">
              <label for="name">Nama</label>
              <input type="text" class="form-control" name="name" id="name" placeholder="example: John Doe">
            </div>
            <div class="form-group col-md-6">
              <label for="phone">Nomor Telepon</label>
              <input type="text" class="form-control" name="phone" id="position" placeholder="example: 1234567890">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="address">Alamat</label>
              <input type="text" class="form-control" name="address" id="name" placeholder="example: Jalan ABC NO. 123">
            </div>
            <div class="form-group col-md-6">
              <label for="position">Jabatan</label>
              <input type="text" class="form-control" name="position" id="position" placeholder="example: Supervisor">
            </div>
          </div>
        

        <input type="submit" value="Submit" class="btn btn-primary" style="margin-left:46%; margin-right:50%;">

    </form>

</div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/reference/create.blade.php ENDPATH**/ ?>