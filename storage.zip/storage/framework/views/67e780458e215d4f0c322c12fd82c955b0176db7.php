<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    
    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <style>
        .active {
            font-weight: bolder;
        }
        
    </style>
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <h1 style="font-size: 15px; padding-top:4px; font-weight:bold;">
                    <a  class="typewrite" data-period="2000" data-type='["ERAKOMP CAREER CENTER"]'>
                      <span class="wrap"></span>
                    </a>
                  </h1>
               <!-- <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    ERAKOMP CAREER
                </a>-->
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                   




                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Masuk</a>
                        </li>
                        <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">Daftar</a>
                        </li>
                        <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php if(Auth::user()->image): ?>
                                <img class="image rounded-circle" src="<?php echo e(asset('/storage/images/'.Auth::user()->image)); ?>" alt="profile_image" style="width: 80px;height: 80px; padding: 10px; margin: 0px; ">
                                <?php endif; ?> <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>


        <main class="py-4 container">

            <?php if(auth()->guard()->check()): ?>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item <?php echo e(request()->is('user-detail') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('user-detail.index')); ?>">Bio</a></li>
                    <li class="breadcrumb-item <?php echo e(request()->is('education') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('education.index')); ?>">Pendidikan</a></li>
                    <li class="breadcrumb-item <?php echo e(request()->is('experience') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('experience.index')); ?>">Pengalaman Kerja</a></li>
                    <li class="breadcrumb-item <?php echo e(request()->is('skill') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('skill.index')); ?>">Keahlian</a></li>
                            <li class="breadcrumb-item <?php echo e(request()->is('asing') ? 'active' : ''); ?>"><a
                                href="<?php echo e(route('asing.index')); ?>">Bahasa Asing</a></li>
                                <li class="breadcrumb-item <?php echo e(request()->is('reference') ? 'active' : ''); ?>"><a
                                    href="<?php echo e(route('reference.index')); ?>">Referensi</a></li>
                                    <li class="breadcrumb-item <?php echo e(request()->is('married') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('married.create')); ?>">Status</a></li>
                                        <li class="breadcrumb-item <?php echo e(request()->is('anak') ? 'active' : ''); ?>"><a
                                            href="<?php echo e(route('anak.index')); ?>">Anak</a></li>
                                            <li class="breadcrumb-item <?php echo e(request()->is('relation') ? 'active' : ''); ?>"><a
                                                href="<?php echo e(route('relation.index')); ?>">Relasi</a></li>
                                                <li class="breadcrumb-item <?php echo e(request()->is('organization') ? 'active' : ''); ?>"><a
                                                    href="<?php echo e(route('organization.index')); ?>">Organisasi</a></li>
                                                    <li class="breadcrumb-item <?php echo e(request()->is('health') ? 'active' : ''); ?>"><a
                                                        href="<?php echo e(route('health.create')); ?>">Kesehatan</a></li>
                                                        <li class="breadcrumb-item <?php echo e(request()->is('job') ? 'active' : ''); ?>"><a
                                                            href="<?php echo e(route('job.index')); ?>">Pekerjaan yang dilamar</a></li>
                                                            <li class="breadcrumb-item <?php echo e(request()->is('connection') ? 'active' : ''); ?>"><a
                                                                href="<?php echo e(route('connection.index')); ?>">Rekomendasi Dari Perusahaan</a></li>
                            <li class="breadcrumb-item <?php echo e(request()->is('image') ? 'active' : ''); ?>"><a
                                href="<?php echo e(route('image.create')); ?>">Gambar Profile</a></li>
                                <li class="breadcrumb-item <?php echo e(request()->is('file') ? 'active' : ''); ?>"><a
                                    href="<?php echo e(route('file.create')); ?>">Upload CV</a></li>

                </ol>
            </nav>
            <?php endif; ?>

            
            <div>
                <?php if(session()->has('errors')): ?>
                <ol class="alert alert-danger" role="alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($e); ?></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
                <?php endif; ?>
            </div>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
<script>
    var TxtType = function(el, toRotate, period) {
    this.toRotate = toRotate;
    this.el = el;
    this.loopNum = 0;
    this.period = parseInt(period, 10) || 2000;
    this.txt = '';
    this.tick();
    this.isDeleting = false;
};

TxtType.prototype.tick = function() {
    var i = this.loopNum % this.toRotate.length;
    var fullTxt = this.toRotate[i];

    if (this.isDeleting) {
    this.txt = fullTxt.substring(0, this.txt.length - 1);
    } else {
    this.txt = fullTxt.substring(0, this.txt.length + 1);
    }

    this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

    var that = this;
    var delta = 200 - Math.random() * 100;

    if (this.isDeleting) { delta /= 2; }

    if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
    } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
    }

    setTimeout(function() {
    that.tick();
    }, delta);
};

window.onload = function() {
    var elements = document.getElementsByClassName('typewrite');
    for (var i=0; i<elements.length; i++) {
        var toRotate = elements[i].getAttribute('data-type');
        var period = elements[i].getAttribute('data-period');
        if (toRotate) {
          new TxtType(elements[i], JSON.parse(toRotate), period);
        }
    }
    // INJECT CSS
    var css = document.createElement("style");
    css.type = "text/css";
    css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
    document.body.appendChild(css);
};
</script>
</html>
<?php /**PATH D:\jobClone\JobApplications\resources\views/layouts/home.blade.php ENDPATH**/ ?>