
<?php $__env->startSection('content'); ?>
                    <div class="col-lg-9">
                        <div class="blog-list clearfix">
                            <div class="section-title">
                                
                            </div><!-- end title -->
                            <p><?php echo e($posts->created_at->format('l, d-M-Y')); ?></p>
                            <p><b>Job Title</b> : <?php echo e($posts->title); ?></p>
                            <p><b>Job Description</b> : <?php echo e($posts->description); ?></p>
                            <p><b>Education Requirement</b> : <?php echo e($posts->education); ?> </p>
                            <p><b>Experience(s) Requirement</b> : <?php echo e($posts->experience); ?> years</p>

                                <div class="btn btn-primary"><a href="/">Apply Now</a></div>

                        </div><!-- end blog-list -->
                    </div><!-- end col -->

                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.listing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\jobClone\JobApplications\resources\views/job_details.blade.php ENDPATH**/ ?>